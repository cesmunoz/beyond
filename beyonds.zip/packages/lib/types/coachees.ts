export type CoacheeFormData = {
  email: string;
  fullName?: string;
  company?: string;
};
