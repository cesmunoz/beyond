export type ChangePasswordRequest = {
  email: string;
  password: string;
  confirmHash: string;
};
