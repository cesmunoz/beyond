export default class User {
  fullName!: string;

  email!: string;
}
