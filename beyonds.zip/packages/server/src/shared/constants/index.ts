export enum TransactionActions {
  Put = 'Put',
  Update = 'Update',
  Delete = 'Delete',
  ConditionCheck = 'ConditionCheck',
}
