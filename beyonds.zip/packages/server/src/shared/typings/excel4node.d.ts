declare module 'excel4node';
