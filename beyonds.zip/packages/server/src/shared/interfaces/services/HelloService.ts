export default interface HelloService {
  hello(): Promise<object>;
}
