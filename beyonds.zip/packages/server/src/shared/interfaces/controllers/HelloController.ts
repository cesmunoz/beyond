export default interface HelloController {
  hello(): Promise<object>;
}
