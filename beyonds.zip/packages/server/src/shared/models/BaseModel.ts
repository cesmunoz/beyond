export default class BaseModel {
  public PK!: string;

  public SK!: string;

  public GS1PK?: string;

  public GS1SK?: string;

  public GS2PK?: string;

  public GS2SK?: string;
}
