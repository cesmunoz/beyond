import BaseModel from './BaseModel';

export class CoachModel extends BaseModel {
  public email!: string;

  public fullName!: string;
}
