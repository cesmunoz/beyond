export const ROOT = '/';
export const SIGN_IN = '/signIn';
export const PROCESSES = '/processes';
export const COACHEES = '/coachees';
export const CONFIRM = '/confirm';
export const QUESTIONNAIRE = '/questions';
export const PROFILE = '/profile';
