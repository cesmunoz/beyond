enum APIStatus {
  Idle,
  Fetching,
  Success,
  Failure,
}

export default APIStatus;
